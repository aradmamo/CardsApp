const joi = require('joi')
const cardValidation = joi.object({
    businessName:joi.string().required(),
    businessEmail:joi.string().email().required(),
    businessPhone:joi.string().pattern(/^[0-9\+]+$/).required(),
    businessAddress:joi.string().required(),
    businessIMG:joi.string().allow(null, ''),
})
function validatecard(details){
    return cardValidation.validate(details)

}
module.exports = validatecard