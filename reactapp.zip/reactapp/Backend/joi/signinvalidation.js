const joi = require('joi')

const schemacustomer = joi.object({
    email:joi.string().required().email(),
    password:joi.string().required()
})

function schema(customer){
    return schemacustomer.validate(customer)
}

module.exports = schema