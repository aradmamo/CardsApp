const joi = require('joi')
const customer = joi.object({
    name:joi.string().required().min(3).max(30),
    email:joi.string().required().email(),
    password:joi.string().required().min(6).trim(),
    isBusinessAccount:joi.boolean()
 
})

function custom (custom){
    return customer.validate(custom)
}
module.exports = custom