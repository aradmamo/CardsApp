const operations = require('../../mongoose/cardOperation')
async function updateCard(req,res){
    const cardid = req.params.id;
    if(!cardid){
        return res.status(400).json('put ID of card Please')
    }
    
    const result = await operations.updateOneCard(cardid,req.body)
    if(result !== null){
        return res.json('Updated Successful')
    }return res.status(500).json('Error in Server not Updated')
}
module.exports = updateCard