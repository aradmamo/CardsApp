const oprations = require('../../mongoose/cardOperation')
async function getcards(req,res){
    
    const getcards = await oprations.getallCards()
   return res.json(getcards)
    
}
module.exports = getcards