const operation = require('../../mongoose/cardOperation')
async function deleteCards(req,res){
    const cardid = req.params.id
    if(cardid){
        const result = await operation.deleteOneCard(cardid)
        if(result !== null ){
            res.json('You Deleted Card')
        }
    }
    else{
        res.status(500).json('sorry But Card Dont Delete')
    }
    
}
module.exports = deleteCards