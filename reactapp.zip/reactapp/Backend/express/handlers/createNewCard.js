const oprations = require('../../mongoose/cardOperation')
const validatecard = require('../../joi/validateCard')
async function createnewCard(req,res){
    const result = validatecard(req.body)
    if(result.error){return res.status(400).json(result.error.details[0].message)}
const accountUser = req.business
if(accountUser){
    req.body.userId = req.userId
    if(!req.body.businessIMG){
        const url = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTngEtqn9kc1a2DsO8XnoeJieo0gHwZTZgY4A&usqp=CAU'
        req.body.businessIMG =url
    }
    const cardDB = await oprations.createnewCard(req.body)
   
    if(cardDB == null ){
        return res.status(500).json("Your Email Is Busy")
        
    }
              
    
    res.json(cardDB)

}
else{
    return res.status(405).json("You are not Allowed!")
}
}
module.exports = createnewCard