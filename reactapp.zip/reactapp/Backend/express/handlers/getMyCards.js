const operations = require('../../mongoose/cardOperation')
async function getMyCards(req,res){
    const userID = req.params.id
    const userCards = await operations.getCardsByUser(userID)
    return res.json(userCards)

}
module.exports = getMyCards