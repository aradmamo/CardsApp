const oprations = require('../../mongoose/customerOperation')
const siginjoi = require('../../joi/signinvalidation')
const jwt = require('jsonwebtoken')

async function signincustomer(req,res){
const {error} = siginjoi(req.body)
if(error){
return res.status(400).json(error.details[0].message)}
const {email,password} = req.body;
const jwtExpirySeconds = 300 * 100
const retval = await oprations.signincustomer(email,password)


   if(!retval){
    return res.status(404).json('Email Or Password Wrong !')
   }

 const token = jwt.sign({customer:retval._id,business:retval.isBusinessAccount, role: "captain" },"user",{expiresIn:jwtExpirySeconds} ) 



  return res.json({customer:retval._id,token:token,name:retval.name,business:retval.isBusinessAccount})








}

module.exports = signincustomer





