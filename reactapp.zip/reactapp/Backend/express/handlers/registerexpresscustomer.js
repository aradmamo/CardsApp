const oprations = require('../../mongoose/customerOperation')
const joivalidate = require('../../joi/registerCustomer')
 async function registercustom(req,res){
const result = joivalidate(req.body)
if(result.error)
res.status(400).json(result.error.details[0].message)
try{
     const retval = await oprations.registerCustomer(req.body)
   
     res.json({id:retval._id ,name:retval.name,email:retval.email})
    
}
catch{
    res.status(400).json('Your Email Is Busy !')
}
}
module.exports = registercustom