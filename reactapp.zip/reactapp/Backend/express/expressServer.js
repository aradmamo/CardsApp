const express = require('express')
const server =  express()
server.use(express.json())
const cors =require('cors')
server.use(cors())
//require
const signinCustomer = require('./handlers/signinCustomer')
const deletecard = require('./handlers/deleteCard')
const registercustomer = require('./handlers/registerexpresscustomer')
const createnewCard =require('./handlers/createNewCard')
const updateCard = require('./handlers/updateCard')
const openToken = require('./tokens/openToken')
const checkToken = require('./tokens/checkToken')
const verifyToken = require('./tokens/verifyToken')
const getAllCards = require('./handlers/getAllCards')
const getMyCards = require('./handlers/getMyCards')
;
//customer
server.post('/newcustomer',registercustomer)
server.post('/signinCustomer',signinCustomer)
//check Sign in
server.get('/verifyLogin',openToken,verifyToken)
//cards
server.get('/getMyCards/:id',getMyCards)
server.post('/createNewCard',checkToken,createnewCard)
server.delete('/deleteCard/:id',checkToken,deletecard)
server.get('/getallcards',getAllCards)
server.put('/updateCard/:id',checkToken,updateCard)

server.listen(3000,()=>{console.log("Express is running")})