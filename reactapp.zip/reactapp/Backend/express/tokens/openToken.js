function openToken(req,res,next){
    const bearerHeader = req.headers.tokens
    if(typeof bearerHeader !== 'undefined'){
      
        req.token = bearerHeader;
        next()
    }else{
        res.status(400).json('Error')
    }
}
module.exports = openToken