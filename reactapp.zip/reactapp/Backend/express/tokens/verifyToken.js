const jsonwebtoken=  require('jsonwebtoken');

async function verifyToken(req,res,next){
    
 try{
 
     jsonwebtoken.verify(req.token,"user",(err,afterVerify)=>{
        if(err)
        {
            res.json(err)
        }
        
        else
        {
            res.json({afterVerify})
        } })
  
}

catch{
    return res.status(500).json('Error!')
}
}
 
module.exports = verifyToken
