
const jsonwebtoken=  require('jsonwebtoken');

async function authenticateCustomer(req,res,next){
        //  .  נשלח טוקן .  
        const  token = req.headers.tokens
        if(!token)
            return  res.status(401).json('no have token');
 
            try
            {
             const data =  jsonwebtoken.verify(token, 'user');
             req.userId = data.customer
             req.business = data.business
                  next();
            }
            catch
            {
                return  res.status(401).json('the token is wrongful');
            }
   
       
}

module.exports= authenticateCustomer;