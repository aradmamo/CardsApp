const modelCard = require('./cardModel')
async function createnewCard(details){
    try{
return await new modelCard(details).save()

}
catch{
    return null
}
}
async function getallCards(){
    try{
        return await modelCard.find() 
        
    }
    catch{
        return null

    }
}
async function deleteOneCard(cardid){
    try{
      return await modelCard.deleteOne({_id:cardid})
}
catch{
    return null
}
}
async function updateOneCard(id,cardUpdateData){
    try{
       const result ={
        _id:id
       }
       
       return await modelCard.findByIdAndUpdate(result,cardUpdateData)
    }
    catch{
        return null
    }

}
async function getCardsByUser(userID){

      try
      {
            return await  modelCard.find({ userId:userID } );
                 
      }
       
    catch{
      return null;
    }

}
module.exports = {createnewCard,getallCards,deleteOneCard,updateOneCard,getCardsByUser}