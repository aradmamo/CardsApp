const mongoose = require('mongoose')
const person =  mongoose.Schema({
    name:String,
    email:{type:String,
    unique:true},
    password:String,
    isBusinessAccount:Boolean

})
 module.exports = mongoose.model('users',person)