const mongoose = require('mongoose')
const schemaofCards = mongoose.Schema({
    businessName:String,
    businessEmail:String,
    businessPhone:String,
    businessAddress:String,
    businessIMG:String,
    userId:String
}, { versionKey: false })
const cardModel = mongoose.model('cardsBusiness',schemaofCards)

module.exports = cardModel