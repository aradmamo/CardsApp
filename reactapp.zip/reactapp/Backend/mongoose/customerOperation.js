const model = require('./customerModel')
const bcrypt = require('bcryptjs')
async function registerCustomer (custom){
try{
    custom.password = bcrypt.hashSync(custom.password)
return await new model(custom).save()
}
catch{
    return null 

}
}
async function signincustomer(email,password){
  try{  const customer = await model.findOne({
        email:email
    })
    if(customer && (await bcrypt.compare(password,customer.password))){
        return customer
    }
          
}
    catch{
        return null

    }
    
    

}



module.exports = {registerCustomer,signincustomer}