import { BrowserRouter, Routes, Route } from "react-router-dom";


import './index.css'
import Welcome from "./components/Welcome/Welcome";
import { useEffect, useState } from 'react';
import Header from "./components/Header/HeaderNav";
import Login from './components/Login/Login'
import CreateCard from "./components/CreateCards/CreateCards";
import RegisterBusiness from "./components/Register/RegisterBusiness";
import Logout from "./components/Logout/Logout";
import Home from './components/Home/Home'
import Footer from "./components/Footer/Footer";
import GetMyCards from "./components/GetMyCards/GetMyCards"
import GetCards from "./components/GetCards/GetcardsNew";
import UpdateCard from "./components/UpdateCard/UpdateCard";
import MissingRoute from "./components/Error/MissingRoute";
import HomeUser from "./components/Home/homeUser";
import AboutPage from "./components/About/About";
function App() {

  return(
 <BrowserRouter>
<header>
  <Header  />
</header>
 <Routes>

  <Route path ='/' element={<Welcome />}/>
  <Route path ='/home' element={<Home />}/>
  <Route path ='/about' element={<AboutPage />}/>
  <Route path ='/homeUser' element={<HomeUser/>}/>
  <Route path='/register' element={<RegisterBusiness/>}/>  
  <Route path='/signinCustomer' element={<Login/>}/>
  <Route path='/getMyCards' element={<GetMyCards/>}/>
  <Route path='/createNewCard' element={<CreateCard/>}/>
  <Route path="/logoutCustomer" element={<Logout/>}/>
  <Route path="/getallcards" element= {<GetCards/>}/>
  <Route path="/UpdateCard" element= {<UpdateCard/>}/>
  <Route path="*" element={<MissingRoute/>} />
 </Routes>
 <Footer/>
 </BrowserRouter>
)}

      export default App