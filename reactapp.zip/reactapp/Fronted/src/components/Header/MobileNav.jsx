import { useState } from "react"

import { useNavigate } from "react-router-dom";
export default function MobileNav(){
  const nav = useNavigate()
    const [menu, setMenu] = useState(true);
     const humburger = () => {
    const med = window.matchMedia("(max-width: 560px)");
    const menuMobile = document.querySelector(".littleMenu");
 document.querySelector('.container-burger').classList.toggle('changemobile')
    if (menu === true) {
      if (med.matches) {
        menuMobile.style.display = "block";
      }
      setMenu(!menu);
    } else {
      setMenu(!menu);
      menuMobile.style.display = "none";
    }
  };
  return (
  <>
     <div className="navbarMobile">
          <div className="container-burger" onClick={() => humburger()}>
            <div className="bar1"></div>
            <div className="bar2"></div>
            <div className="bar3"></div>
          </div>
          <nav className="littleMenu">
            <ul>
              <li onClick={() => nav("/homeUser")}>
              <i className="fa-solid fa-house"></i>
              </li>
              <li onClick={() =>{ nav("/getMyCards")}}>
                 <i className="fa-brands fa-cc-paypal"></i>
              </li>
              <li onClick={() => nav("/getallcards")}>
                <i className="fa-regular fa-credit-card"></i>
              </li>
              <li onClick={() => nav("/logoutCustomer")}>
                                <i className="fa-solid fa-arrow-right-from-bracket"></i>

              </li>
              <li onClick={() => nav("/createNewCard")}>
                <i className="fa-solid fa-user-plus"></i>
              </li>
            </ul>
          </nav>
        </div>
  
  </>
  )
}