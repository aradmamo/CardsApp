import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import "./header.css";
import Navbar from "react-bootstrap/Navbar";
import { NavLink, useNavigate } from "react-router-dom";
import { useState } from "react";
import MobileNav from "./MobileNav";
import MobileGuest from "./MobileGuest";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

export default function Header() {
  const [isActive, setActive] = useState(false);


  const toggleClass = () => {
    setActive(!isActive);
  };
  if (localStorage.getItem("tokens")) {
   
  
   
    return (
      <>
      <MobileNav/>
        <Navbar bg="dark" variant="dark" className="navbar">
          <Container>
            <Row className="row-menu">
              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/homeUser">
                   <i className="fa-solid fa-house"></i>
                  Home
                </NavLink>
              </Col>
              <Col 
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink  className="header"  to="/getMyCards">
                  
             <i className="fa-brands fa-cc-paypal"></i>
                  Get my cards
                </NavLink>
              </Col>

              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/getallcards">
                  <i className="fa-regular fa-credit-card"></i>
                  Get cards
                </NavLink>
              </Col>
              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/logoutCustomer">
               <i className="fa-solid fa-arrow-right-from-bracket"></i>
                  Logout
                </NavLink>
              </Col>
              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/createNewCard">
                <i className="fa-solid fa-user-plus"></i>
                  Create card
                </NavLink>
              </Col>
            </Row>
          </Container>
        </Navbar>
      </>
    );
  } else {
    return (
      <>
     
        <MobileGuest/>
        <Navbar bg="dark" variant="dark" className="navbar">
          <Container>
            <Row className="row-menu">
              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/home">
                  {" "}
                 <i className="fa-solid fa-house"></i>
                  Home
                </NavLink>
              </Col>

              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/about">
                  {" "}
             <i className="fa-solid fa-address-card"></i>
                  About
                </NavLink>
              </Col>

              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/register">
                  {" "}
                <i className="fa-solid fa-registered"></i>
                  Register
                </NavLink>
              </Col>
           
              <Col
                onClick={() => {
                  toggleClass();
                }}
              >
                <NavLink className="header" to="/signinCustomer">
                  {" "}
                  <i className="fa-solid fa-user"></i>
                  Login
                </NavLink>
              </Col>
            </Row>
          </Container>
        </Navbar>
      </>
    );
  }
}
