import { useState } from "react";

import { useNavigate } from "react-router-dom";

export default function MobileGuest(){
    const nav =useNavigate()
      const [menu, setMenu] = useState(true);
const humburger = () => {
    const med = window.matchMedia("(max-width: 560px)");
    const menuMobile = document.querySelector(".littleMenu");
    document.querySelector('.container-burger').classList.toggle('changemobile')

    if (menu === true) {
      if (med.matches) {
        menuMobile.style.display = "block";
      }
      setMenu(!menu);
    } else {
      setMenu(!menu);
      menuMobile.style.display = "none";
    }
  };
  return(
    <>
     <div className="navbarMobile">
          <div className="container-burger" onClick={() => humburger()}>
            <div className="bar1"></div>
            <div className="bar2"></div>
            <div className="bar3"></div>
          </div>
          <nav className="littleMenu">
            <ul>
              <li onClick={() => nav("/home")}>
                    <i className="fa-solid fa-house"></i>
              </li>
              <li onClick={() => nav("/about")}>
               <i className="fa-solid fa-address-card"></i>
              </li>
              <li onClick={() => nav("/register")}>
                <i className="fa-solid fa-registered"></i>
              </li>
             
              <li onClick={() => nav("/signinCustomer")}>
                  <i className="fa-solid fa-user"></i>
              </li>
            </ul>
          </nav>
        </div>
    </>
  )
}