import "./about.css"
import * as React from 'react';
import { styled } from '@mui/material/styles';
import { Icon } from '@mui/material';
import MuiAccordion from '@mui/material/Accordion';
import MuiAccordionSummary from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';

const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  '&:not(:last-child)': {
    borderBottom: 0,
  },
  '&:before': {
    display: 'none',
  },
}));

const AccordionSummary = styled((props) => (
  <MuiAccordionSummary
    expandIcon={<Icon sx={{ fontSize: '0.1rem' }} />}
    {...props}
  />
))(({ theme }) => ({
  backgroundColor:
    theme.palette.mode === 'dark'
      ? 'rgba(255, 255, 255, .05)'
      : 'rgba(0, 0, 0, .1)',
  flexDirection: 'row-reverse',
  '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
    transform: 'rotate(90deg)',
  },
  '& .MuiAccordionSummary-content': {
    marginLeft: theme.spacing(1),
  },
  height:"110px",
  borderTop: "1px solid snow"
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
  borderTop: 'snow 1px solid',
  background:"rgba(255, 255, 255, 0.7)",
  paddingLeft:'35px',
}));

export default function AboutPage() {
  const [expanded, setExpanded] = React.useState('panel1');

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };
 
  return (
    <div className="sectionAbout">
      <div className="containerAbout">
      <h1 className="titleAbout">About us</h1>
      <Accordion  expanded={expanded === 'panel1'} sx={{backgroundColor:"rgba(0,0,0,.5)"}}  onChange={handleChange('panel1')}>
        <AccordionSummary   aria-controls="panel1d-content" id="panel1d-header">
          <Typography>About myself</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography className="aboutmyself">
            Hello everyone i am Arad Mamo from Moshav Shahar i am 22 years old and after Army,this is my Graduation Project for HackerU ,I am hope you  enjoy in my Web.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion sx={{backgroundColor:"rgba(0,0,0,.5)"}} expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
        <AccordionSummary aria-controls="panel2d-content" id="panel2d-header">
          <Typography>Languages </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          This is my first project to requires fullstack and first time i trying  with react and nodejs,i choose in react js for client side and nodejs for server side,
         for client i used in vite with react js ,HTML, CSS, JS ,BootStrap and React-Icons-fa. 
          for server i used Mongoose ,Express Server, bcryptjs, Json Web Token and  joi for validation.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion sx={{backgroundColor:"rgba(0,0,0,.5)"}} expanded={expanded === 'panel3'} className="lastAcc" onChange={handleChange('panel3')}>
        <AccordionSummary aria-controls="panel3d-content" id="panel3d-header">
          <Typography>Task</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            In this projoct we had to use in all CRUD Operations with The business Cards,in my Website you can add new business card , set favorite card ,edit and delete card.
          </Typography>
        </AccordionDetails>
        </Accordion>
      <p className="myPhone">for any problem or question :(*972)050-367-6060 - arad mamo </p>
    </div>
    </div>
  );
}









   