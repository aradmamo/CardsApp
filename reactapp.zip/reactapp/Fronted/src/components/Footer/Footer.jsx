import { FaInstagram, FaFacebookMessenger } from "react-icons/fa";
import "./footer.css";
export default function Footer() {
  return (
    <div className="footer">
      <h3 className="titleFooter ">Created By Arad Mamo 2022</h3>
      <div className="contIcons">
        <a
          href="http://www.instagram.com"
          className="instagram icon"
          target="_blank"
        >
          {" "}
          <i className="fa-brands fa-instagram"></i>
        </a>
        <a
          className="facebook icon"
          href="http://www.facebook.com"
          target="_blank"
        >
          <i className="fa-brands fa-facebook"></i>
        </a>
        <a className="twiter icon" href="https://twitter.com" target="_blank">
          <i className="fa-brands fa-twitter"></i>
        </a>
        <a
          className="linkdin icon"
          href="https://www.linkedin.com"
          target="_blank"
        >
          <i className="fa-brands fa-linkedin"></i>
        </a>
      </div>
      <div className="logo"></div>
    </div>
  );
}
