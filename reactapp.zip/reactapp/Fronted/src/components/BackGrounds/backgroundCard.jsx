import './background.css'
export default function DynamicBackground(){
    return(
        <div style = {{backgroundColor:"black"}} >

    <div className="bg-animation">
        <div id="stars"></div>
        <div id="stars2"></div>
        <div id="stars3"></div>
        <div id="stars4"></div>
    </div>

</div>
    )
}