import './cube.css'
export default function Cube(){
    return (
         <>
           <div className="cube"></div>
       <div className="cube"></div>
       <div className="cube"></div>
       
       <div className="cube"></div>
      <div className="cube"></div>
         </>
    )
}