import "./logout.css";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import DynamicBackground from "../BackGrounds/backgroundCard";
export default function Logout() {
  const navigate = useNavigate();
  const back = () => {
    const arr = ["tokens", "id", "name"];
    setTimeout(() => {
      window.location.replace("/home");
    }, 1000);

    arr.forEach((e) => {
      localStorage.removeItem(e);
    });
    document.querySelector(".beforeRefresh").innerHTML =
      "Thank you for visited us...";
  };

  return (
    <div className="logoutContainer">
      <a className="linkToSignOut" onClick={() => back()}>
        Back To Home{" "}
      </a>
      <div className="beforeRefresh"></div>
    </div>
  );
}
