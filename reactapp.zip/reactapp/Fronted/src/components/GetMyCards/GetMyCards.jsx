import { useEffect, useState } from "react";
import * as React from "react";
import "../GetCards/GetCards.css";
import DynamicBackground from "../BackGrounds/backgroundCard";
import { FaEdit, FaEraser, FaStar, FaInfo } from "react-icons/fa";
import "./getMyCards.css";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import SearchCard from "../Search/SearchCard";
import { useNavigate } from "react-router-dom";
import CustomPopup from "../PopupCard/CustomPopup";
var mycards = [];
var myCardsFromDB;
export default function GetMyCards() {
  const navigate = useNavigate();
  const local = localStorage.getItem("id");
  const [getmycards, setGetmycards] = useState([]);
  const [popcard, setPopcard] = useState({});

  const [data, setData] = useState(null);
  const [visibility, setVisibility] = useState(false);

  const popupCloseHandler = (e) => {
    setVisibility(e);
  };

  myCardsFromDB = () => {
    fetch("http://localhost:3000/getMyCards/" + local)
      .then((res) => {
        if (res.ok) {
          return res.json();
        }
        console.log(res);
      })
      .then((data) => {
        setData(data);
        mycards = [...data];
        setGetmycards(mycards);
      })
      .catch((err) => console.log(err));
  };
  useEffect(() => {
    myCardsFromDB();
  }, []);

  const addToFav = (item) => {
    Array.prototype.forEach.call(cards, function (el) {
      let id = el.getAttribute("data-id");
      if (id == item._id) {
        let starElm = el.getElementsByClassName("starFav")[0];
        if (localStorage.getItem(id) === null) {
          localStorage.setItem(id, "Fav");
          starElm.classList.add("gold");
        } else {
          localStorage.removeItem(id);
          starElm.classList.remove("gold");
        }
      }
    });
  };

  function searchCard(text) {
    const u = mycards.filter((x) => {
      return x.businessName.indexOf(text) > -1;
    });
    setGetmycards([...u]);
  }

  const myNewCards = getmycards.map((element, index) => {
    return (
      <Card
        className="myCard"
        data-id={element._id}
        key={index}
        sx={{ maxWidth: 300 }}
      >
        <CardActionArea>
          <CardMedia
            className="imgcard"
            component="img"
            height="120"
            image={element.businessIMG}
            alt="Img do Not Found"
          />
          <CardContent className="contentCard">
            <Typography component={"span"} variant={"body2"}>
              <h5>{element.businessName} </h5>
            </Typography>
            <Typography
              component={"span"}
              variant={"body2"}
              color="text.secondary"
            >
              <div className="cardContent">
                <label className="labelCard">
                  <i className="fa-solid fa-envelope"></i>
                </label>
                <small>{element.businessEmail}</small>
                <label className="labelCard">
                  <i className="fa-sharp fa-solid fa-location-dot"></i>
                </label>
                <small> {element.businessAddress}</small>

                <label className="labelCard">
                  <i className="fa-solid fa-phone"></i>
                </label>
                <small> {element.businessPhone}</small>
              </div>
              <span
                onClick={() => deleteOneCard(element._id)}
                className="btnDelete"
              >
                <FaEraser />
              </span>
              <span className="btnEdit" onClick={() => updateCard(element)}>
                <FaEdit />
              </span>
              <span
                className="starFav"
                id={"star" + element._id}
                onClick={() => addToFav(element)}
              >
                <FaStar />
              </span>
              <span
                className="info"
                onClick={(e) => {
                  setPopcard(element);
                  setVisibility(!visibility);
                }}
              >
                <FaInfo />
              </span>
            </Typography>
          </CardContent>
        </CardActionArea>
      </Card>
    );
  });

  function updateCard(card) {
    navigate(`/UpdateCard`, { state: { card: card } });
  }

  const cards = document.getElementsByClassName("myCard");

  Array.prototype.forEach.call(cards, function (el) {
    let id = el.getAttribute("data-id");
    let storageCard = localStorage.getItem(id);

    if (storageCard !== null) {
      let fav = el.getElementsByClassName("starFav")[0];
      fav.classList.add("gold");
    }
  });

  return (
    <>
      <DynamicBackground />
      <main className="searchInput">
        <SearchCard onChange={(e) => searchCard(e)} />
      </main>
      <section className="containerCards">
        {myNewCards.length > 0 ? (
          myNewCards
        ) : (
          <h1>There are no Business Cards</h1>
        )}
        <CustomPopup
          onClose={popupCloseHandler}
          show={visibility}
          title="More Details"
        >
          <div className="cardDetails">
            <img
              className="imageDetails"
              src={popcard.businessIMG}
              alt="Image not Found"
            />
            <div className="rowInfo">
              <label>
                <i className="fa-solid fa-business-time detailsIcon"></i>
              </label>
              <h2 className="cardInfo">{popcard.businessName}</h2>
            </div>
            <div className="rowInfo">
              <label>
                <i className="fa-solid fa-envelope detailsIcon"></i>
              </label>
              <h2 className="cardInfo">{popcard.businessEmail}</h2>
            </div>
            <div className="rowInfo">
              <label>
                <i className="fa-sharp fa-solid fa-location-dot detailsIcon"></i>
              </label>
              <h2 className="cardInfo">{popcard.businessAddress}</h2>
            </div>
            <div className="rowInfo">
              <label>
                <i className="fa-solid fa-phone detailsIcon"></i>
              </label>
              <h2 className="cardInfo">{popcard.businessPhone}</h2>
            </div>
          </div>
        </CustomPopup>
      </section>
    </>
  );

  function deleteOneCard(id) {
    fetch("http://localhost:3000/deleteCard/" + id, {
      method: "delete",
      headers: {
        tokens: localStorage.getItem("tokens"),
      },
    })
      .then((x) => {
        if (x.status == 401) {
          navigate("/../signinCustomer");
          localStorage.clear();
          alert("You dont been here a long time please Sign in again!");
          window.location.reload();
        } else {
          if (localStorage.getItem(id)) {
            localStorage.removeItem(id);
          }
          mycards.splice(id, 1);
          myCardsFromDB();
        }
      })

      .catch((err) => console.log(err));
  }
}
