import axios from "axios";
import { useRef, useState } from "react";
import { FaUserAltSlash, FaCheck, FaAsterisk } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import "./register.css";
export default function RegisterBusiness() {
  const nav = useNavigate();
  const [account, setAccount] = useState(true);
  const nameRef = useRef();
  const emailRef = useRef();
  const passwordRef = useRef();
  const pressRadio = () => {
    document.querySelector(".remark").style.display = "none";
  };
  return (
    <div className="containerRegister">
      <form onSubmit={register} className="formRegister">
        <div className="section">
          <label className="labelRegister" htmlFor="name">
            Name:
          </label>
          <div className="rowRegister">
            <input
              type="text"
              placeholder="Enter Name"
              ref={nameRef}
              minLength={3}
              maxLength={20}
              className="input"
              name="name"
              id="name"
              required
            />
            <span style={{ visibility: "hidden" }} className="checkName check ">
              <FaCheck />
            </span>
          </div>
        </div>
        <div className="section">
          <label className="labelRegister" htmlFor="email">
            Email:
          </label>
          <div className="rowRegister">
            <input
              type="email"
              minLength={10}
              maxLength={40}
              placeholder="Enter Email"
              ref={emailRef}
              name="email"
              id="email"
              className="input"
              required
            />
            <span style={{ visibility: "hidden" }} className="check">
              <FaCheck />
            </span>
          </div>
        </div>
        <div className="section">
          <label className="labelRegister" htmlFor="password">
            Password:
          </label>
          <div className="rowRegister">
            <input
              type="password"
              placeholder="Enter Password"
              name="password"
              ref={passwordRef}
              minLength={6}
              maxLength={20}
              id="password"
              className="input"
              required
            />
            <span style={{ visibility: "hidden" }} className="check ">
              <FaCheck />
            </span>
          </div>
        </div>
        <div className="section">
          <label className="labelRegister" htmlFor="password1">
            Confirm Password:
          </label>
          <div className="rowRegister">
            <input
              type="password"
              placeholder="Enter Password again"
              name="password1"
              id="password1"
              className="input"
              required
            />
            <span style={{ visibility: "hidden" }} className="check ">
              <FaCheck />
            </span>
          </div>
        </div>
        <div className="accountBusiness">
          <label className="labelRegister">Bussiness Account:</label>
          <div className="optionsRadio">
            <div>
              <input
                type="radio"
                id="isBusinessAccount"
                name="isBusinessAccount"
                onChange={(e) => {
                  setAccount(e.target.checked);
                  pressRadio();
                }}
                value={account}
              />
              <label className=" confirmAccount" htmlFor="isBusinessAccount">
                <FaCheck />
              </label>
            </div>
            <div>
              <input
                type="radio"
                className="radioOption"
                id="notActiveUser"
                name="isBusinessAccount"
                onChange={(e) => {
                  setAccount(!e.target.checked);
                  pressRadio();
                }}
                value={account}
              />

              <label
                className="optionBusiness refusalAccount"
                htmlFor="notActiveUser"
              >
                <FaUserAltSlash />
              </label>
            </div>
          </div>
        </div>
        <p className="remark">The default option is True !</p>
        <div className="submitButton">
          <input type="submit" id="btnRegister" value="Register" />
        </div>
        <div id="root2"></div>
      </form>
    </div>
  );

  function register(e) {
    e.preventDefault();
    const pass = document.getElementById("password").value;
    const pass1 = document.getElementById("password1").value;
    const root = document.getElementById("root2");

    if (pass === pass1) {
      axios
        .post("http://localhost:3000/newcustomer", {
          name: nameRef.current.value,
          email: emailRef.current.value,
          password: passwordRef.current.value,
          isBusinessAccount: isBusinessAccount.value,
        })
        .then((x) => {
          if (x.status === 200) {
            const check = document.querySelectorAll(".check");
            check.forEach((block) => {
              block.style.visibility = "visible";
            });
            root.innerHTML = "Successful To Register";
            root.style.backgroundColor = "snow";
            root.style.color = "green";
            setTimeout(() => {
              nav("/signinCustomer");
            }, 1000);
          } else {
            root.innerHTML = x;
            root.style.color = "black";
            root.style.backgroundColor = "red";
          }
        })

        .catch((error) => {
          if (error.response) {
            root.innerHTML = error.response.data;
          } else {
            root.innerHTML = error.message;
          }
        });
    } else {
      root.innerHTML = "passwords do not match";
      root.style.color = "black";
      root.style.backgroundColor = "red";
    }
  }
}
