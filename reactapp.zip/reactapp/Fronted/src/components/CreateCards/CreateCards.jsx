import { useEffect, useState } from "react";
import "./cards.css";
import { Navigate, useNavigate } from "react-router-dom";
import { FaCheck } from "react-icons/fa";
import DynamicBackground from "../BackGrounds/backgroundCard";
import axios from "axios";
export default function CreateCard() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [image, setImage] = useState("");
  if (name.length >= 3) {
    document.querySelector(".checkName").style.visibility = "visible";
  } else {
    const checkName = document.querySelector(".checkName");
    if (checkName) {
      checkName.style.visibility = "hidden";
    }
  }
  if (
    (email.length >= 8 &&
      email.includes("@") &&
      email.includes(".") &&
      email.endsWith("com")) ||
    email.endsWith("co.il") ||
    email.endsWith("net") ||
    email.endsWith("org")
  ) {
    document.querySelector(".checkEmail").style.visibility = "visible";
  } else {
    const checkEmail = document.querySelector(".checkEmail");
    if (checkEmail) {
      checkEmail.style.visibility = "hidden";
    }
  }
  if (phone.length >= 7) {
    document.querySelector(".checkPhone").style.visibility = "visible";
  } else {
    const checkPhone = document.querySelector(".checkPhone");
    if (checkPhone) {
      checkPhone.style.visibility = "hidden";
    }
  }
  if (address.length >= 3) {
    document.querySelector(".checkAddress").style.visibility = "visible";
  } else {
    const checkAddress = document.querySelector(".checkAddress");
    if (checkAddress) {
      checkAddress.style.visibility = "hidden";
    }
  }

  return (
    <div className="contCreateCards">
      <DynamicBackground />
      <form className="createCardForm" onSubmit={createNewCard}>
        <h1 className="titleFormCards">
          <b> Create New Card</b>
        </h1>
        <div className="addnewcard">
          <div className="block">
            <label className="label-card">Business Name:</label>
            <div className="rowCard">
              <input
                type="text"
                className="newCardCreate"
                value={name}
                placeholder="Enter name"
                onChange={(e) => {
                  setName(e.target.value);
                }}
                id="businessName"
                required
                minLength={3}
                maxLength={35}
              />{" "}
              <span
                className="check checkName"
                style={{ visibility: "hidden" }}
              >
                <FaCheck />
              </span>
            </div>
          </div>
          <div className="block">
            <label className="label-card">Business Email:</label>
            <input
              type="email"
              placeholder="Enter Email"
              className="newCardCreate "
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
              }}
              id="businessEmail"
              required
              minLength={8}
              maxLength={25}
            />
            <span className="checkEmail check" style={{ visibility: "hidden" }}>
              <FaCheck />
            </span>
          </div>
          <div className="block">
            <label className="label-card">Business Phone:</label>
            <input
              type="tel"
              placeholder="Enter Phone"
              className="newCardCreate"
              pattern="[0-9]+"
              id="businessPhone"
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value);
              }}
              required
              minLength={7}
              maxLength={20}
            />
            <span className="checkPhone check" style={{ visibility: "hidden" }}>
              <FaCheck />
            </span>
          </div>
          <div className="block">
            <label className="label-card">Business Address:</label>
            <input
              type="text"
              placeholder="Enter Address"
              className="newCardCreate"
              value={address}
              onChange={(e) => {
                setAddress(e.target.value);
              }}
              id="businessAddress"
              required
              minLength={2}
              maxLength={30}
            />
            <span
              className="checkAddress check"
              style={{ visibility: "hidden" }}
            >
              <FaCheck />
            </span>
          </div>
          <div className="block">
            <label className="label-card">Business Image:</label>
            <textarea
              maxLength={600}
              className="newCardCreate"
              rows={3}
              cols={30}
              placeholder="Enter Url "
              id="businessIMG"
              onChange={(e) => setImage(e.target.value)}
              value={image}
            ></textarea>
            <span className="check">
              <FaCheck />
            </span>
          </div>

          <input id="Submit" type="submit" value="Create Card" />
          <div id="result"></div>
        </div>
      </form>
    </div>
  );

  function createNewCard(e) {
    e.preventDefault();
    let res = document.getElementById("result");

    axios
      .post(
        "http://localhost:3000/createNewCard",
        {
          businessName: name,
          businessEmail: email,
          businessPhone: phone,
          businessAddress: address,
          businessIMG: image,
        },
        { headers: { tokens: localStorage.getItem("tokens") } }
      )
      .then((x) => {
        if (x.status === 200) {
          if (x === "the token is wrongful") {
            navigate("/../signinCustomer");
            localStorage.clear();
            alert("You were AFK a long time, please sign in again.");
            window.location.reload();
          } else {
            res.innerHTML = "Successful to create card";

            res.style.color = "green";
            res.style.background = "rgba(0,0,0,.5)";
          }
        }
      })

      .catch((error) => {
        res.innerHTML = error.response.data;
        res.style.color = "red";
        res.style.background = "black";
      });
  }
}
