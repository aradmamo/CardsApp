import { useNavigate } from "react-router-dom"
import "./error.css"
export default function MissingRoute(){
    const navigate = useNavigate()
    function navi(){
        navigate('./home')
        
    }
   
    return(
 <>
 <section className="sectionError">
        <h1>Sorry  You have a Navigation Error !</h1>
<p>if you need help to  <u style={{color:"green"}} onClick={()=>navi()}> Back Home</u> </p>
</section>

</>
)}