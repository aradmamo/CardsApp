import React from "react";
export default class Confirm extends React.Component{
   
    render(){
        
    }
}
