import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login.css";

export default function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="loginContainer">
      <form className="myformLogin" onSubmit={signin}>
        <h3 className="title-form">Login</h3>
        <div className="div1">
          <label htmlFor="email">
            <u>Email:</u>
          </label>
          <input
            name="email"
            className="signinput"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
          />
        </div>
        <div className="div1">
          <label htmlFor="password">
            <u>Password:</u>
          </label>

          <input
            name="password"
            className="signinput"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
          />
        </div>
        <div>
          <input className="sendBtn" type="submit" value="Login" />
        </div>
        <p
          className="linkToRegister"
          onClick={() => {
            nav("/register");
          }}
        >
          Sign up
        </p>
        <p id="root1" className="responsefromdb"></p>
      </form>
    </div>
  );
  function signin(e) {
    e.preventDefault();
    const root = document.getElementById("root1");

    axios
      .post("http://localhost:3000/signinCustomer", {
        email: email,
        password: password,
      })
      .then((x) => {
        localStorage.setItem("tokens", x.data.token);
        localStorage.setItem("id", x.data.customer);
        localStorage.setItem("name", x.data.name);

        const options = {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            tokens: localStorage.getItem("tokens"),
          },
        };
        fetch("http://localhost:3000/verifyLogin", options)
          .then((response) => response.json())
          .then((x) => {
            if (typeof x === "object") {
              root.style.color = "green";
              root.innerHTML = "You are connected...";
              setTimeout(() => {
                window.location.replace("/homeUser");
              }, 2000);
            }
          });
      })

      .catch((error) => {
        root.innerHTML = error.response.data;
        setPassword("");
      });
  }
}
