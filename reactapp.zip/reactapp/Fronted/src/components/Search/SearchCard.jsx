import { useState } from "react";
import './search.css'

export default function SerachCard(props){
  let [text, setText] = useState("");
  return (
    <>
    <input
    id="search"
      type="text"
      placeholder="enter card name to search"
      value={text}
      onChange={(e) => {
        setText(e.target.value);
        props.onChange(e.target.value);
      }}
    />
  </>
  );
}