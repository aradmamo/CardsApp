import "./getCards.css"
import axios from "axios"
import React from "react"
import DynamicBackground from "../BackGrounds/backgroundCard";
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography, { typographyClasses } from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import SerachCard from "../Search/SearchCard";
import { useEffect } from "react";
export default class GetCards extends React.Component {
    constructor(props){
        super(props)
this.state = {
    cards :[],
}
    }

 componentDidMount(){
axios.get(`http://localhost:3000/getallcards`)
.then(res=>{
    const cards = res.data
 this.setState({cards})
})
}


render(){
   const allCards = this.state.cards.map(element =>{
   
    return(
   <Card className="unauthorizedCard"  key={element._id}  sx={{ maxWidth:300}}>
      <CardActionArea  >
        <CardMedia className='imgcard'
          component="img"
          height="120"
          image= {element.businessIMG}
          alt="Img do Not Found"
        />
        <CardContent className='contentCard'>
        
          <Typography component={'span'} variant={'body2'}>
            <h5>{element.businessName}</h5><br/>
          </Typography>
          <Typography component={'span'} variant={'body2'}
 color="text.secondary">
           <label>Email:</label>{element.businessEmail}
           <br/>
          <label>Address</label> {element.businessAddress}<br/>
          <label >Phone</label>
           {element.businessPhone}</Typography>
  <br/>
           
      
        </CardContent>
      </CardActionArea>
    </Card>


)
}
)


return(
  <>
    <DynamicBackground/>
  <div className="containergetCards">
  {allCards}
</div>
</>
) 
 
}

}