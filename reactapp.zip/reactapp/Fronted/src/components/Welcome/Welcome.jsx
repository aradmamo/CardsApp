import DynamicBackground from "../BackGrounds/backgroundCard";
import "./welcome.css";
import ReactCardSlider from "react-card-slider-component";
export default function Welcome() {
  const sliderClick = () => {
    return;
  };
  const slides = [
    {
      image: "https://picsum.photos/100/500",
      title: "This is a Business Card",
      description: "example@example.com\n055-555-5555\nIsrael,Tel Aviv ",
      email: "123",
      clickEvent: sliderClick,
    },
    {
      image: "https://picsum.photos/600/500",
      title: "This is a second title",
      description: "example@example.com\n055-555-5555\nIsrael,Tel Aviv ",
      clickEvent: sliderClick,
    },
    {
      image: "https://picsum.photos/200/300",
      title: "This is a title",
      description: "example@example.com\n055-555-5555\nIsrael,Tel Aviv ",
      clickEvent: sliderClick,
    },
    {
      image: "https://picsum.photos/400/200",
      title: "This is a second title",
      description: "example@example.com\n055-555-5555\nIsrael,Tel Aviv ",
      clickEvent: sliderClick,
    },
    {
      image: "https://picsum.photos/500/300",
      title: "This is a title",
      description: "example@example.com\n055-555-5555\nIsrael,Tel Aviv ",
      clickEvent: sliderClick,
    },
    {
      image: "https://picsum.photos/400/500",
      title: "This is a second title",
      description: "example@example.com\n055-555-5555\nIsrael,Tel Aviv ",
      clickEvent: sliderClick,
    },
  ];
  return (
    <>
      <DynamicBackground />
      <div>
        <h1 className="titleApp">Welcome To Card business Web</h1>
      </div>
      <div className="sliderCards">
        <h1 style={{ fontFamily: "arial", color: "rgba(0,0,0,.4)" }}>
          Example of a business cards
        </h1>
        <ReactCardSlider slides={slides} />
      </div>
    </>
  );
}
