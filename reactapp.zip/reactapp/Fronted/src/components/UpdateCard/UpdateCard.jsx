import React, { useState } from "react";
import "./updatecards.css"
import {useLocation, useNavigate} from 'react-router-dom';
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
export default function  UpdatemyCard(){
 
    const nav = useNavigate()
     const location = useLocation();
    const card =location.state.card
const [name,setName]= useState(card.businessName)
const [email,setEmail]= useState(card.businessEmail)
const [phone,setPhone]= useState(card.businessPhone)
const [address,setAddress]= useState(card.businessAddress)
const [img,setImg]= useState(card.businessIMG)

    return(<div className="contUpdate">
        <form className="formUpdate" onSubmit={updateCard}   >
            <h1 className="titleUpdate">Update Card</h1>
            <div  className="blockUpdate">
<label className="labelForUpdate">New Name:</label>
<input type="text" value={name} placeholder="New card name" className="inpUpdate" required minLength={3} maxLength={15}  id="businessName" onChange={(e)=>{setName(e.target.value)}}/>
</div>
<div className="blockUpdate"><label className="labelForUpdate">New Email:</label>
<input type="email" value={email} placeholder="New card email" className="inpUpdate" required minLength={8} maxLength={35}   id="businessEmail"  onChange={(e)=>{setEmail(e.target.value)}} /></div>
<div className="blockUpdate"><label className="labelForUpdate">New Phone:</label>
<input type="text"  value={phone} placeholder="New card phone" className="inpUpdate"  required maxLength={45} id="businessPhone"  onChange={(e)=>{setPhone(e.target.value)}} /></div>
<div className="blockUpdate"><label className="labelForUpdate">New Address:</label>
<input type="text"  value={address} placeholder="New card address" className="inpUpdate" required maxLength={55}  id="businessAddress"  onChange={(e)=>{setAddress(e.target.value)}} /></div>
<div className="blockUpdate"><label className="labelForUpdate">New Image:</label>
<input type="text"   value={img} placeholder="New card image" className="inpUpdate"    id="businessIMG"  onChange={(e)=>{setImg(e.target.value)}} /></div>

<input type="submit" className="submitCard" value="Send"  />
<div className="ans"></div>


        </form>
        <Card  className="cardUpdate"  sx={{ maxWidth: 300 }}>
        <CardActionArea >
          <CardMedia
            className="imgcard"
            component="img"
            height="120"
            image={img}
            alt="Img do Not Found"
          />
          <CardContent className="contentUpdate">
            <Typography component={"span"} variant={"body2"}>
              <h3>{name}</h3>
            </Typography>
            <Typography
              component={"span"}
              variant={"body2"}
              color="text.secondary"
            >
              <div className="cardContentforUpdate">
                <h4>{email}</h4>
            
               <h4>{phone}</h4>
 <h4>{address}</h4>
              
             
               
            
              </div>
              
              </Typography>
              </CardContent>
            
        </CardActionArea>
      </Card>
        </div>
    )
    function updateCard(e){
    e.preventDefault()
const obj = {
    businessName:businessName.value,
    businessEmail:businessEmail.value,
    businessPhone:businessPhone.value,
    businessAddress:businessAddress.value,
    businessIMG:businessIMG.value,
}
fetch("http://localhost:3000/updateCard/" + card._id, {
    body:JSON.stringify(obj),
    method: "put",
   headers: { "Content-Type": "application/json" ,
        "tokens":localStorage.getItem('tokens') }
  })
  .then(x=>x.json())
  .then((res)=>{if(res === 'Updated Successful'){
nav('/getMyCards')
  }
  else{
    document.querySelector('.ans').innerHTML = 'Your Email Is Already Exists'
  }
})
  
    .catch((err) => console.log(err+"!!!"));
}
}
