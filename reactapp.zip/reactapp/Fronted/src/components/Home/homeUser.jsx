import { useNavigate } from 'react-router-dom'
import Cube from '../BackGrounds/cube'
import './home.css'
export default function HomeUser(){
  const nav = useNavigate()
  const name = localStorage.getItem('name')

 return(
            <div className="container-fluid">
    <div className="background">
      <Cube/>
       <section className="header-content">
         <h1>Welcome {name}</h1>
        <p> Welcome to the team.Business Cards!.
            <br />
         You are a new Friend in our Website,
          <br />
         We are very hope that you will be enjoy with us.
         </p>
         
        <button id='btn1'  onClick={()=> nav('/getMyCards')}>Get my Cards</button>
        <button  onClick={()=> nav('/createNewCard')}>Create Card</button>
      </section>
    </div>
 
     
    </div>
        )
   
}
