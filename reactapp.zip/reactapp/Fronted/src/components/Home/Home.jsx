import { useNavigate } from 'react-router-dom'
import Cube from '../BackGrounds/cube'
import './home.css'
export default function Home(){
  const nav = useNavigate()

 
 return(
            <div className="container-fluid">
    <div className="background">
     <Cube/>
       <section className="header-content">
         <h1>Welcome</h1>
        <p> Welcome to the team.Business Cards!.
            <br />
         With us you can add new safe cards bussiness, and more... <br />
         We are very hope that you will be enjoy with us.
         </p>
         
        <button id='btn1'  onClick={()=> nav('/register')}>register</button>
        <button  onClick={()=> nav('/signinCustomer')}>login</button>
      </section>
    </div>
 
     
    </div>
        )
   
}
